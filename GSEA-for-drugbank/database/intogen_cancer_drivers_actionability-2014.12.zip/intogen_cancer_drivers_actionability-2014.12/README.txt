File contents
-----------------
Protein_Drug_Interactions.tsv
	Interactions of 96/475 cancer driver genes in Drivers Database with therapeutic agents
Protein_druggability.tsv
	Exclusvie druggability of 157/475 driver genes according interactions in Protein_Drug_Interactions.tsv
Drug_details.tsv
	Description of each drug
Drug_FDAapproved_rules.tsv
	Rules for prescription of FDA approved drugs to genomic alterations
Drug_ClinicalTrials_rules.tsv
	Rules for prescription of drugs in clinical trials to genomic alterations
Drug_resistances_rules.tsv
	Rules for not prescribing drugs to samples bearing genomic alterations of primary resistance 


Specificities
-----------------
*In most of the files tumor types are represented through its acronyms (see Drivers Database)

*Specific genomic dependencies/evidences/resistances are codified in the same unified code in the Columns () in the files (Drug_resistances_rules.tsv, Drug_FDAapproved_rules.tsv, Drug_ClinicalTrials_rules.tsv). 
The coding rules are:
- All of them are divided in mutations/CNAs/fusions. 
- For each one, different genes with alterations are semicolon (;) divided.
- Each gene differs from its alterions with colon(:) and its different alterations are comma (,) divided. 
	i.e BRAF:V600E,V600K (two diferent alterations)
- For CNAs A stants for Amplification and D for delention.
	i.e. FGFR1:A
- For mutations all of them are specified at protein level lik referenceAA+proteinposition+alteredAA.
	i.e. BRAF:V600E,V600K
  except mutational requirements not based on AA change but specific consequence type, which are specified by ::CT:: after the gene.
	i.e. NOTCH1::CT::missense_variant:2380-2445;CT::feature_truncation:2380-2445
- Fusion partners are divided with dash (-).
	i.e. BCR-ABL1
- A dot (.) represents any.
	i.e. BRAF:V600. (any alteredAA)
	i.e. BRAF:. (any PAM mutation)

